#define _GNU_SOURCE
#include "unistd.h"
#include "process_log.h"
#include <stdlib.h>
#include <stdio.h>
#include <linux/kernel.h>
#include <sys/syscall.h>

int get_proc_log_level(){
	return syscall(336);
}

int set_proc_log_level(int new_level){
    return syscall(335, new_level);
}

int proc_log_message(int level, char *message){
    return syscall(PROC_LOG_CALL, message, level);
}

int* retrieve_set_level_params(int new_level){
    int* arr = malloc(sizeof(int)*3);
    arr[0] = 335;
    arr[1] = 1;
    arr[2] = new_level;
    return arr;
}

int* retrieve_get_level_params(){
	int* arr = malloc(sizeof(int)*2);
    arr[0] = 336;
    arr[1] = 0;
    return arr;
}

int interpret_set_level_result(int ret_value){
    return ret_value;
}

int interpret_get_level_result(int ret_value){
    return ret_value;
}

int interpret_log_message_result(int ret_value){
    return ret_value;
}



